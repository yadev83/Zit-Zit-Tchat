######### Rendu du projet de réseau
- ATTIA Yanis
- SANCHEZ Jean-Christophe
- CORTOPASSI Martin
- BRU Valentin

Pour compiler le projet, se placer à la racine et appeler la commande "make"
Pour executer un serveur : "./out/ZZTs" depuis la racine du projet.
Pour executer un client  : "./out/ZZTc" depuis la racine du projet.

Commandes client : 
"!login <pseudo>" - permet de se faire identifier sous un pseudo
"!list" - Renvoie la liste des pseudos connectés
"!hello" - envoie le message de bienvenue au client
"!quit" - se déconnecte du serveur

Autres :
"<msg>" - envoie un message au serveur qui le retransmet aux clients.
