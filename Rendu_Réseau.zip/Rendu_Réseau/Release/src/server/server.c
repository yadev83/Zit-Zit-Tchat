#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <netdb.h> 
#include <netinet/in.h> 
#include <arpa/inet.h>

#include <sys/socket.h> 
#include <sys/types.h> 

#include "server.h"
#include "../interpreter/interpreter.h"

void getData(int sockfd){
    char buffer[BUFF_MAX];
    int n = 0;

    while(1){
        bzero(buffer, BUFF_MAX);

        n = read(sockfd, buffer, BUFF_MAX);
        printf("Message reçu : %s (%d Bytes)\n", buffer, n);
        
        if(strcmp(buffer, "exit") == 0){
            write(sockfd, "QUIT", 5);
            printf("SERVER CLOSING NOW\n");
            break;
        }else{
            write(sockfd, "OK", 3);
        }
    }
}

struct sockaddr_in *newServ(int domain, in_addr_t addr, int port){
    struct sockaddr_in *servaddr = NULL;
    
    servaddr = (struct sockaddr_in *) malloc(sizeof(struct sockaddr_in));
    bzero(servaddr, sizeof(struct sockaddr_in)); 

    servaddr->sin_family = domain; 
    servaddr->sin_addr.s_addr = htonl(addr); 
    servaddr->sin_port = htons(port); 
  
    return servaddr;
}

//Server main function
int main(void){
    int sockfd, connfd, len; 
    struct sockaddr_in *servaddr;
    struct sockaddr_in *cli; 

    // socket connecté en mode IPv4
    sockfd = socket(PF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        perror("socket creation failed");
        exit(-1); 
    } 
    else{
        printf("Socket successfully created..\n"); 
    }

    // assign IP, PORT 
    servaddr = newServ(PF_INET, INADDR_ANY, PORT);

    // Binding newly created socket to given IP and verification 
    if ((bind(sockfd, servaddr, sizeof(struct sockaddr_in))) != 0) { 
        perror("socket bind failed");
        exit(-2); 
    } 
    else{
        printf("Socket successfully binded..\n"); 
    }

    // Now server is ready to listen and verification 
    if ((listen(sockfd, CLIENT_MAX)) != 0) { 
        perror("listen failed");
        exit(-3); 
    } 

    cli = (struct sockaddr_in *) malloc(sizeof(struct sockaddr_in));
    len = sizeof(*cli);

    printf("Server listening..\n");
  
    /*// Accept the data packet from client and verification 
    // Single client version
    connfd = accept(sockfd, cli, &len); 
    if (connfd < 0) { 
        perror("server could not accept connection");
        exit(-4); 
    } 
    else{
        printf("Server acccepted the client...\n"); 
    }
    // SERVER READY AND ACCEPTED CONNECTION, LISTENING...
    getData(connfd);*/

    //Multi-client version
    int multiconfd[CLIENT_MAX];

    fd_set readfds;
    int max_sd, activity;

    char buffer[BUFF_MAX];
    char buffToSend[BUFF_MAX*2];
    char idGadjo[BUFF_MAX*2];
    char tmpPort[6];
    int n = 0;

    char **pseudos = (char **) malloc(sizeof(char *) * CLIENT_MAX);

    for(int i = 0; i < CLIENT_MAX; ++i){
        multiconfd[i] = 0;
        pseudos[i] = NULL;
    }

    while(1){
        //Gestion des pelos déjà connectés
        FD_ZERO(&readfds);
        
        FD_SET(sockfd, &readfds);
        max_sd = sockfd;

        for(int i = 0; i < CLIENT_MAX; ++i){
            if(multiconfd[i] > 0){
                FD_SET(multiconfd[i], &readfds);
            }

            if(multiconfd[i] > max_sd){
                max_sd = multiconfd[i];
            }
        }

        activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
        if((activity < 0)){
            perror("CA VA PAS SE PASSER COMME CA");
        }

        //Connexion entrante
        if(FD_ISSET(sockfd, &readfds)){
            connfd = accept(sockfd, (struct sockaddr *)cli, (socklen_t*)&len);
            if (connfd < 0) { 
                perror("server could not accept connection");
                exit(-4); 
            } else{
                for(int i = 0; i < CLIENT_MAX; ++i){
                    if(multiconfd[i] == 0){
                        multiconfd[i] = connfd;
                        printf("Server accepted a new connection on socket #%d @[%s:%d]\n", connfd, inet_ntoa(cli->sin_addr), ntohs(cli->sin_port));
                        for(int j = 0; j < CLIENT_MAX; ++j){
                            if(i != j && multiconfd[j] != 0 && multiconfd[j] != connfd){
                                strcpy(idGadjo, "[");
                                strcat(idGadjo, inet_ntoa(cli->sin_addr));
                                strcat(idGadjo, ":");
                                sprintf(tmpPort, "%d", ntohs(cli->sin_port));
                                strcat(idGadjo, tmpPort);
                                strcat(idGadjo, "] ");
                                strcpy(buffToSend, idGadjo);
                                strcat(buffToSend, "Joined\0");
                                write(multiconfd[j], buffToSend, strlen(buffToSend));
                            }
                        }
                        break;
                    }
                }
            }
        }else{
            //Gestion des I/O sur les connexions existantes
            for(int i = 0; i < CLIENT_MAX; ++i){
                connfd = multiconfd[i];

                if(FD_ISSET(connfd, &readfds)){
                    bzero(buffer, BUFF_MAX);
                    n = read(connfd, buffer, BUFF_MAX);
                    getpeername(connfd , (struct sockaddr*)cli , (socklen_t*)&len);
                    printf("Message reçu socket %d @[%s:%d]\n>> %s (%d Bytes)\n", connfd, inet_ntoa(cli->sin_addr), ntohs(cli->sin_port), buffer, n);
                    if(buffer[0] == '!'){
                        
                        //Message "commande"
                        interpreter(buffer);

                        //Login
                        if(strcmp(getCmd(), "login") == 0){
                            printf("Now creating login\n");
                            if(pseudos[i] != NULL)
                                free(pseudos[i]);
                            pseudos[i] = (char *) malloc(sizeof(char) * strlen(getElement()));
                            strcpy(pseudos[i], getElement());
                            write(connfd, "You username has changed", 26);
                        }else if(strcmp(getCmd(), "list") == 0){
                            char list[BUFF_MAX*CLIENT_MAX] = "";
                            for(int i = 0; i < CLIENT_MAX; ++i){
                                if(pseudos[i] != NULL){
                                    strcat(list, pseudos[i]);
                                    strcat(list, " | ");
                                }
                            }
                            write(connfd, list, 750);
                        }else if(strcmp(getCmd(), "hello") == 0){
                            write(connfd, "Bienvenue sur le Zit-Zit-Tchat !", 33);
                        }else if(strcmp(getCmd(), "quit") == 0){
                            //Exit
                            printf("Now closing a connection\n");
                            write(connfd, "QUIT", 5);
                            close(connfd);
                            multiconfd[i] = 0;
                            printf("Gadjo déconnecté [%s:%d]\n", inet_ntoa(cli->sin_addr) , ntohs(cli->sin_port));
                            for(int j = 0; j < CLIENT_MAX; ++j){
                                if(i != j && multiconfd[j] != 0 && multiconfd[j] != connfd){
                                    strcpy(idGadjo, "[");
                                    if(pseudos[i] == NULL){
                                        strcat(idGadjo, inet_ntoa(cli->sin_addr));
                                        strcat(idGadjo, ":");
                                        sprintf(tmpPort, "%d", ntohs(cli->sin_port));
                                        strcat(idGadjo, tmpPort);
                                    }else{
                                        strcat(idGadjo, pseudos[i]);
                                    }
                                    strcat(idGadjo, "] ");
                                    strcpy(buffToSend, idGadjo);
                                    strcat(buffToSend, "Left the server");
                                    write(multiconfd[j], buffToSend, strlen(buffToSend));
                                }
                            }
                        }
                    }else{
                        //Message "broadcast"
                        for(int j = 0; j < CLIENT_MAX; ++j){
                            if(i != j && multiconfd[j] != 0 && multiconfd[j] != connfd){
                                strcpy(idGadjo, "[");
                                if(pseudos[i] == NULL){
                                    strcat(idGadjo, inet_ntoa(cli->sin_addr));
                                    strcat(idGadjo, ":");
                                    sprintf(tmpPort, "%d", ntohs(cli->sin_port));
                                    strcat(idGadjo, tmpPort);
                                }else{
                                    strcat(idGadjo, pseudos[i]);
                                }
                                strcat(idGadjo, "] ");
                                strcpy(buffToSend, idGadjo);
                                strcat(buffToSend, buffer);
                                write(multiconfd[j], buffToSend, strlen(buffToSend));
                            }
                        }
                        write(connfd, "OK", 3);
                    }
                }
            }
        }
    }

    // After chatting close the socket 
    close(sockfd); 
}